


<?php $__env->startSection('content'); ?>

<table>
    <thead>
    <th>Name</th>
    <th>Color</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item -> productName); ?></td>
            <td><?php echo e($item -> productName); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Uzair\Desktop\New folder (3)\furniturestore2\resources\views/cart/index.blade.php ENDPATH**/ ?>